﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Appium.Windows;
using System.Threading;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Enums;

namespace UnitTestProject1
{
    class Program
    {
        // Note: append /wd/hub to the URL if you're directing the test at Appium
        private const string WindowsApplicationDriverUrl = "http://127.0.0.1:4723";
        private const string CalculatorAppId = "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App";
        protected static WindowsDriver<WindowsElement> session;

        private static WindowsElement header;
        private static WindowsElement calculatorResult;

        public static void Setup()
        {
            // Launch Calculator application if it is not yet launched
            if (session == null)
            {
                // Create a new session to bring up an instance of the Calculator application
                var appiumOptions = new AppiumOptions();
                appiumOptions.AddAdditionalCapability(MobileCapabilityType.DeviceName, "WindowsPC");
                appiumOptions.AddAdditionalCapability(MobileCapabilityType.PlatformName, "Windows");
                appiumOptions.AddAdditionalCapability(MobileCapabilityType.App, CalculatorAppId);
                session = new WindowsDriver<WindowsElement>(new Uri(WindowsApplicationDriverUrl), appiumOptions);
                Assert.IsNotNull(session);

                // Set implicit timeout to 1.5 seconds to make element search to retry every 500 ms for at most three times
                session.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1.5);

                //Identify calculator mode by locating the header
                try
                {
                    header = session.FindElementByAccessibilityId("Header");
                }
                catch
                {
                    header = session.FindElementByAccessibilityId("ContentPresenter");
                }

                // Ensure that calculator is in standard mode
                if (!header.Text.Equals("Standard", StringComparison.OrdinalIgnoreCase))
                {
                    session.FindElementByAccessibilityId("TogglePaneButton").Click();
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                    var splitViewPane = session.FindElementByClassName("SplitViewPane");
                    splitViewPane.FindElementByName("Standard Calculator").Click();
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                    Assert.IsTrue(header.Text.Equals("Standard", StringComparison.OrdinalIgnoreCase));
                }


                // Locate the calculatorResult element
                calculatorResult = session.FindElementByAccessibilityId("CalculatorResults");
                Assert.IsNotNull(calculatorResult);
            }
        }

        public void Multiplication()
        {
            // Find the buttons by their names using XPath and click them in sequence to perform 9 x 9 = 81
            session.FindElementByXPath("//Button[@Name='Nine']").Click();
            session.FindElementByXPath("//Button[@Name='Multiply by']").Click();
            session.FindElementByXPath("//Button[@Name='Eight']").Click();
            session.FindElementByXPath("//Button[@Name='Equals']").Click();
            Console.WriteLine(GetCalculatorResultText());
            Assert.AreEqual("72", GetCalculatorResultText());
        }
        public void Subtraction()
        {
            // Find the buttons by their accessibility ids using XPath and click them in sequence to perform 9 - 1 = 8
            session.FindElementByXPath("//Button[@AutomationId=\"num9Button\"]").Click();
            session.FindElementByXPath("//Button[@AutomationId=\"minusButton\"]").Click();
            session.FindElementByXPath("//Button[@AutomationId=\"num1Button\"]").Click();
            session.FindElementByXPath("//Button[@AutomationId=\"equalButton\"]").Click();
            Console.WriteLine(GetCalculatorResultText());
            Assert.AreEqual("8", GetCalculatorResultText());
        }
        private string GetCalculatorResultText()
        {
            return calculatorResult.Text.Replace("Display is", string.Empty).Trim();
        }



        public static void TearDown()
        {
            // Close the application and delete the session
            if (session != null)
            {
                session.Quit();
                session = null;
            }
        }

        public static void Main(string[] args)
        {
            Program Program = new Program();
            Program.Setup();
            Program.Multiplication();
            Program.Subtraction();
            Program.TearDown();

        }
    }

}
